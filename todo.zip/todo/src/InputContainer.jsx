import React from 'react'
import "./styles/input.css"
const InputContainer = ({addHandler}) => {

  let newString ="";

  return (
    <div className='todo_input_container'>
      <input className='todo_input' onChange={(event)=>{newString= event.target.value}}/>
      <button className="todo_add_button" onClick={()=>{addHandler(newString)}}> Add </button>
    </div>
  )
}

export default InputContainer
