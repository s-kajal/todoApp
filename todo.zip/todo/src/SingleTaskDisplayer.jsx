import React from 'react'
import "./styles/todo.css"
const SingleTaskDisplayer = ({task, index,deleteHandler}) => {
  return (
    <li className='single_task'>
      <span className='task_text'>{task}</span>
      <button className='delete_button' onClick={()=>{deleteHandler(index)}}>Delete</button>
    </li>
  )
}

export default SingleTaskDisplayer
