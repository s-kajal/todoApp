import { useState } from 'react';
import InputContainer from './InputContainer';
import TaskDisplayer from './TaskDisplayer';
import "./styles/App.css"
function App() {

  const [taskList , setTaskList] = useState([]);
  function addHandler( str){
      setTaskList([...taskList, str]);
      }
  
  function deleteHandler( index ){
      let tempArr = [...taskList];
      tempArr.splice(index, 1);
      setTaskList(tempArr);
  }

  return (
    <div className="App">
      <div className='todo_container'>
        <h1>MY TASKS</h1>
        <InputContainer addHandler={addHandler}/>
        <TaskDisplayer taskList={taskList} deleteHandler={deleteHandler}/>
      </div>
    </div>
  );
}

export default App;
