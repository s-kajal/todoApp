import React from 'react'
import SingleTaskDisplayer from "./SingleTaskDisplayer"
import "./styles/todo.css"
const TaskDisplayer = ({taskList,deleteHandler}) => {
  return (
    <div className='taskDispalyer_container'>
        <ul className='task_list'>
           {taskList.map((task, index)=>{
            return <SingleTaskDisplayer task={task} index={index} deleteHandler={deleteHandler}/>
           })}
        </ul>
    </div>
  )
}

export default TaskDisplayer
